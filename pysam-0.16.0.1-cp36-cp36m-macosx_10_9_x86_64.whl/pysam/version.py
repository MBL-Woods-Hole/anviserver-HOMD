# pysam versioning information
__version__ = "0.16.0.1"

__samtools_version__ = "1.10"
__bcftools_version__ = "1.10.2"
__htslib_version__ = "1.10.2"
